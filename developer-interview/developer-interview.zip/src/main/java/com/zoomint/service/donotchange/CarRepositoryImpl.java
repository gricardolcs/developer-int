package com.zoomint.service.donotchange;

import com.zoomint.service.Car;

import java.util.List;


/**
 * DO NOT CHANGE THIS CLASS
 */


public class CarRepositoryImpl implements CarRepository {
	public Car save(Car newCar) {
		return null;
	}

	public List<Car> findAllCarsInGarage() {
		return null;
	}

	public int delete(int carId) {
		return 0;
	}
}
